/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javacrud;

/**
 *
 * @author Lenovo
 */
public class JavaCRUD {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
